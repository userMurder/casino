API_TOKEN = "7372539904:AAF6JMhQSmccs_AsbZEyCuHWHTNF6Iefpm0"
CRYPTOPAY_API_TOKEN = "14880:AAW6zQUw7cXosXB0Ppk4m6UjawgiMPqH0Yc"
Network = "TEST_NET"
admin_id = 6533430904
LOG_FILE = 'casino_log.db'  # Файл базы данных для логов
chat_id_log = -1002204538874
coefficient = 0.8 # Коф на кубик
box_cof = 1
coff_chislo = 3.1
REFERRAL_FILE = "reffelal.db"
win_id = -1002159384360
BOT_USERNAME = 'FulldBetBot'

image_paths = {
    'even': 'dice_even.jpg',
    'odd': 'dice_odd.jpg',
    'higher': 'dice_more.jpg',
    'lower': 'dice_less.jpg',
    'win': 'dice_2.jpg',
    'lose': 'dice_1.jpg'
}





